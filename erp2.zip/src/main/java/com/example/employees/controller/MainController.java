package com.example.employees.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

    @GetMapping("/main")
    public String getMain() {
        return "index";
    }

    @GetMapping("/maina")
    public String getMaina() {
        return "index2";
    }

    @GetMapping("/account")
    public String getAccount() {
        return "settings/pages-account-settings-account";
    }

    @GetMapping("/not")
    public String getNot() {
        return "settings/pages-account-settings-notifications";
    }

    @GetMapping("/connections")
    public String getC() {
        return "settings/pages-account-settings-connections";
    }

    @GetMapping("/card")
    public String getCard() {
        return "components/cards-basic";
    }

    @GetMapping("/inputs")
    public String getInputs() {
        return "forms/forms-basic-inputs";
    }

    @GetMapping("/groups")
    public String getGroups() {
        return "forms/forms-input-groups";
    }

    @GetMapping("/vertical")
    public String getVertical() {
        return "forms/form-layouts-vertical";
    }

    @GetMapping("/horizontal")
    public String getHorizontal() {
        return "forms/form-layouts-horizontal";
    }

    @GetMapping("/announcement")
    public String getA() {
        return "announcement/announcement";
    }

    @GetMapping("/calendar")
    public String getCalendar() {
        return "calendar/calendar";
    }

}
